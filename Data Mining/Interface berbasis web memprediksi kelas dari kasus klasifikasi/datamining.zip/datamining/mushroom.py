import pickle
import streamlit as st 

mushroom_model = pickle.load(open('mushroom_model.sav', 'rb'))

st.title('Data Mining Mushroom')

capshape= st.text_input('input nilai cap-shape')
capsurface= st.text_input('input nilai cap-surface')
capcolor= st.text_input('input nilai cap-color')
bruises= st.text_input('input nilai bruises')
odor= st.text_input('input nilai odor')
gillattachment= st.text_input('input nilai gill-attachment')
gillspacing= st.text_input('input nilai gill-spacing')
gillsize= st.text_input('input nilai gill-size')
gillcolor= st.text_input('input nilai gill-color')
stalkshape= st.text_input('input nilai stalk-shape')
stalkroot= st.text_input('input nilai stalk-root')
stalksurfaceabovering= st.text_input('input nilai stalk-surface-above-ring')
stalksurfacebelowring= st.text_input('input nilai stalk-surface-below-ring')
stalkcolorabovering= st.text_input('input nilai stalk-color-above-ring')
stalkcolorbelowring= st.text_input('input nilai stalk-color-below-ring')
veiltype= st.text_input('input nilai veil-type')
veilcolor= st.text_input('input nilai veil-color')
ringnumber= st.text_input('input nilai ring-number')
ringtype= st.text_input('input nilai ring-type')
sporeprintcolor= st.text_input('input nilai spore-print-color')
population= st.text_input('input nilai population')
habitat= st.text_input('input nilai habitat')

# code untuk prediksi
mushroom_diagnosis = ''

#membuat tombol untuk prediksi
if st.button('Tes Prediksi Jamur Beracun'):
	mushroom_prediction = mushroom_model.predict([['poisonous', 'cap-shape', 'cap-surface', 'cap-color', 'bruises', 'odor', 'gill-attachment', 'gill-spacing', 'gill-size', 'gill-color', 'stalk-shape', 'stalk-root', 'stalk-surface-above-ring', 'stalk-surface-below-ring', 'stalk-color-above-ring', 'stalk-color-below-ring', 'veil-type', 'veil-color', 'ring-number', 'ring-type', 'spore-print-color', 'population', 'habitat']])

	if(mushroom_prediction[0] == 1):
		mushroom_diagnosis = 'beracun'
	else :
		mushroom_diagnosis = 'tidak beracun'
st.success(mushroom_diagnosis)

